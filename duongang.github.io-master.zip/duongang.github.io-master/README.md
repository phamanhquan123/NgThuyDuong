Cảm ơn đã đọc đây là code tôi lấy từ 1 người khác vì khá là lười code -)) <br/>
Nếu bạn muốn chỉnh sửa nó mà chưa hiểu về code thì hãy hỏi tôi tại liên kết
<br/> https://www.facebook.com/profile.php?id=100047579678526
